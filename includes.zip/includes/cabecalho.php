<?php
// Componente de cabeçalho com todas as meta tags de SEO compartilhadas
require_once "configuracao.php";

// Valores padrão que podem ser sobrescritos por cada página individual
$titulo_pagina = $configuracao_site['nome_site'];
$descricao_pagina = $configuracao_site['descricao_geral'];
$url_canonica = $configuracao_site['url_base'] . $_SERVER['REQUEST_URI'];
$imagem_pagina = $seo_padrao['imagem_compartilhamento'];
$tipo_pagina = $seo_padrao['tipo_site'];
?>
<!DOCTYPE html>
<html lang="<?php echo $seo_padrao['linguagem']; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Meta Tags Básicas de SEO -->
    <title><?php echo $titulo_pagina; ?></title>
    <meta name="description" content="<?php echo $descricao_pagina; ?>">
    <link rel="canonical" href="<?php echo $url_canonica; ?>">
    <meta name="robots" content="index, follow">

    <!-- Open Graph para Redes Sociais -->
    <meta property="og:title" content="<?php echo $titulo_pagina; ?>">
    <meta property="og:description" content="<?php echo $descricao_pagina; ?>">
    <meta property="og:url" content="<?php echo $url_canonica; ?>">
    <meta property="og:type" content="<?php echo $tipo_pagina; ?>">
    <meta property="og:site_name" content="<?php echo $configuracao_site['nome_site']; ?>">
    <meta property="og:image" content="<?php echo $imagem_pagina; ?>">
    <meta property="og:locale" content="pt_BR">

    <!-- Twitter Cards -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $titulo_pagina; ?>">
    <meta name="twitter:description" content="<?php echo $descricao_pagina; ?>">
    <meta name="twitter:image" content="<?php echo $imagem_pagina; ?>">

    <!-- Links de Estilos -->
    <link rel="stylesheet" href="/css/estilo-artigos.css">
</head>
<body>

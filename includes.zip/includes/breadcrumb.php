<?php
function gerar_breadcrumb($itens_breadcrumb){
    $saida = '<nav class="navegacao-breadcrumb">';
    $saida .= '<a href="/">Início</a>';

    foreach($itens_breadcrumb as $item){
        $saida .= ' > ';
        if(!empty($item['url'])){
            $saida .= '<a href="'.htmlspecialchars($item['url']).'">'.htmlspecialchars($item['nome']).'</a>';
        } else {
            $saida .= '<span>'.htmlspecialchars($item['nome']).'</span>';
        }
    }

    $saida .= '</nav>';
    return $saida;
}
?>

<?php
// Inclui o arquivo de conexão com o banco de dados
require_once "conexao.php";

// Função para gerar Slugs amigáveis para URLs
function gerar_slug($texto) {
    $texto = strtolower($texto);
    $texto = preg_replace('/[áàâãäéèêëíìîïóòôõöúùûüç]/', ['a','a','a','a','a','e','e','e','e','i','i','i','i','o','o','o','o','o','u','u','u','u','c'], $texto);
    $texto = preg_replace('/[^a-z0-9-]/', '-', $texto);
    $texto = preg_replace('/-+/', '-', $texto);
    return trim($texto, '-');
}

// Função para sanitizar entradas e evitar ataques XSS
function sanitizar_entrada($dado) {
    global $conexao;
    $dado = trim($dado);
    $dado = stripslashes($dado);
    $dado = htmlspecialchars($dado, ENT_QUOTES, 'UTF-8');
    $dado = $conexao->real_escape_string($dado);
    return $dado;
}

// Função para proteger contra CSRF
function gerar_token_csrf() {
    if (!isset($_SESSION['token_csrf'])) {
        session_start();
        $_SESSION['token_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['token_csrf'];
}

function validar_token_csrf($token) {
    session_start();
    if (isset($_SESSION['token_csrf']) && $token === $_SESSION['token_csrf']) {
        unset($_SESSION['token_csrf']);
        return true;
    }
    return false;
}

// Função para calcular tempo de leitura do artigo
function calcular_tempo_leitura($conteudo) {
    $quantidade_palavras = str_word_count(strip_tags($conteudo));
    $tempo = ceil($quantidade_palavras / 200);
    return $tempo < 1 ? 1 : $tempo;
}

// Função para registrar visualização de artigo sem contagem repetida do mesmo IP
function registrar_visualizacao_artigo($artigo_id) {
    global $conexao;
    $ip_usuario = $_SERVER['REMOTE_ADDR'];
    $data_limite = date('Y-m-d H:i:s', strtotime('-24 hours'));

    // Verifica se o IP já visualizou o artigo nas últimas 24 horas
    $consulta = $conexao->prepare("SELECT id FROM visualizacoes WHERE artigo_id = ? AND ip_usuario = ? AND data_visualizacao > ?");
    $consulta->bind_param("iss", $artigo_id, $ip_usuario, $data_limite);
    $consulta->execute();
    $resultado = $consulta->get_result();

    if ($resultado->num_rows === 0) {
        $insercao = $conexao->prepare("INSERT INTO visualizacoes (artigo_id, ip_usuario) VALUES (?, ?)");
        $insercao->bind_param("is", $artigo_id, $ip_usuario);
        $insercao->execute();
    }
}

// Função para obter a quantidade total de visualizações de um artigo
function obter_total_visualizacoes($artigo_id) {
    global $conexao;
    $consulta = $conexao->prepare("SELECT COUNT(*) as total FROM visualizacoes WHERE artigo_id = ?");
    $consulta->bind_param("i", $artigo_id);
    $consulta->execute();
    $resultado = $consulta->get_result()->fetch_assoc();
    return $resultado['total'];
}

// Função para buscar artigos relacionados
function buscar_artigos_relacionados($artigo_id, $categoria_id, $quantidade){
    global $conexao;
    $consulta = $conexao->prepare("SELECT a.id, a.titulo, a.slug, a.imagem_destacada, a.resumo
                                   FROM artigos a
                                   WHERE a.id != ? AND a.categoria_id = ? AND a.status = 'publicado'
                                   ORDER BY RAND()
                                   LIMIT ?");
    $consulta->bind_param("iii", $artigo_id, $categoria_id, $quantidade);
    $consulta->execute();
    return $consulta->get_result()->fetch_all(MYSQLI_ASSOC);
}


?>

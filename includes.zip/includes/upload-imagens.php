<?php
function processar_upload_imagem($arquivo_enviado){
    global $configuracao_site;

    // Valida erros de upload
    if($arquivo_enviado['error'] !== UPLOAD_ERR_OK){
        return ['status' => 'erro', 'mensagem' => 'Erro no envio do arquivo'];
    }

    // Valida tamanho máximo
    if($arquivo_enviado['size'] > $configuracao_site['tamanho_maximo_upload_imagem']){
        return ['status' => 'erro', 'mensagem' => 'Tamanho de arquivo excedeu o limite permitido'];
    }

    // Valida formato permitido
    $extensao_arquivo = strtolower(pathinfo($arquivo_enviado['name'], PATHINFO_EXTENSION));
    if(!in_array($extensao_arquivo, $configuracao_site['formatos_permitidos_upload'])){
        return ['status' => 'erro', 'mensagem' => 'Formato de arquivo não permitido'];
    }

    // Gera nome seguro para o arquivo
    $novo_nome_arquivo = uniqid('img_', true) . '.' . $extensao_arquivo;
    $caminho_destino = __DIR__ . '/../assets/artigos/' . $novo_nome_arquivo;

    // Move arquivo para pasta de destino
    if(move_uploaded_file($arquivo_enviado['tmp_name'], $caminho_destino)){
        return [
            'status' => 'sucesso',
            'mensagem' => 'Upload realizado com sucesso',
            'caminho_arquivo' => '/assets/artigos/' . $novo_nome_arquivo
        ];
    }

    return ['status' => 'erro', 'mensagem' => 'Falha ao salvar o arquivo no servidor'];
}
?>

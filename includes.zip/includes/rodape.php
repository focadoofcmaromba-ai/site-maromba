<?php
// Componente de rodapé compartilhado por todas as páginas
?>
<footer class="rodape-sistema-artigos">
    <div class="conteudo-rodape">
        <div class="bloco-rodape">
            <h3><?php echo $configuracao_site['nome_site']; ?></h3>
            <p>Todo conteúdo sobre musculação, hipertrofia, treinos e saúde para você evoluir com segurança.</p>
        </div>
        <div class="bloco-rodape">
            <h4>Links úteis</h4>
            <ul>
                <li><a href="/">Página inicial</a></li>
                <li><a href="/artigos/">Todos os artigos</a></li>
                <li><a href="/categorias/">Categorias</a></li>
            </ul>
        </div>
        <div class="bloco-rodape">
            <h4>Categorias populares</h4>
            <?php
            $consulta_categorias = $conexao->query("SELECT nome, slug FROM categorias ORDER BY nome ASC LIMIT 5");
            while($categoria = $consulta_categorias->fetch_assoc()){
                echo '<li><a href="/categorias/'.$categoria['slug'].'">'.$categoria['nome'].'</a></li>';
            }
            ?>
        </div>
    </div>
    <div class="direitos-reservados">
        <p>&copy; <?php echo date('Y'); ?> <?php echo $configuracao_site['nome_site']; ?>. Todos os direitos reservados.</p>
    </div>

    <!-- Script estruturado Organization para SEO -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "<?php echo $configuracao_site['nome_site']; ?>",
        "url": "<?php echo $configuracao_site['url_base']; ?>",
        "logo": "<?php echo $configuracao_site['url_base']; ?>/assets/imagem-logo.png"
    }
    </script>

    <!-- Carregamento de scripts do sistema -->
    <script src="/js/funcoes-artigos.js"></script>
</body>
</html>

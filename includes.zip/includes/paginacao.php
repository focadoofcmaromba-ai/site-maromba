<?php
function gerar_paginacao($pagina_atual, $total_registros, $quantidade_por_pagina, $parametros_url = ''){
    $total_paginas = ceil($total_registros / $quantidade_por_pagina);
    if($total_paginas <= 1) return '';

    $saida = '<div class="area-paginacao">';
    $url_base = $_SERVER['PHP_SELF'] . '?';
    if(!empty($parametros_url)) $url_base .= $parametros_url . '&';

    for($i = 1; $i <= $total_paginas; $i++){
        $classe_atual = $i == $pagina_atual ? 'pagina-atual' : '';
        $saida .= '<a href="'.$url_base.'pagina='.$i.'" class="link-paginacao '.$classe_atual.'">'.$i.'</a>';
    }

    $saida .= '</div>';
    return $saida;
}
?>

<?php
// Sistema de cache nativo para otimização de desempenho
function gerar_caminho_cache($identificador_unico){
    $nome_arquivo_cache = md5($identificador_unico) . '.cache';
    return __DIR__ . '/../data/cache/' . $nome_arquivo_cache;
}

// Verifica se o cache existe e é válido dentro do tempo configurado
function verificar_cache_valido($identificador_unico){
    global $configuracao_site;
    $caminho_arquivo = gerar_caminho_cache($identificador_unico);
    
    if(!file_exists($caminho_arquivo)){
        return false;
    }

    $tempo_criacao_arquivo = filemtime($caminho_arquivo);
    $tempo_limite = time() - ($configuracao_site['dias_cache'] * 86400);

    if($tempo_criacao_arquivo < $tempo_limite){
        unlink($caminho_arquivo);
        return false;
    }

    return true;
}

// Retorna o conteúdo salvo no cache
function obter_conteudo_cache($identificador_unico){
    $caminho_arquivo = gerar_caminho_cache($identificador_unico);
    return file_get_contents($caminho_arquivo);
}

// Salva novo conteúdo no cache
function salvar_conteudo_cache($identificador_unico, $conteudo){
    // Garante que a pasta de cache existe
    if(!is_dir(__DIR__ . '/../data/cache/')){
        mkdir(__DIR__ . '/../data/cache/', 0755, true);
    }
    $caminho_arquivo = gerar_caminho_cache($identificador_unico);
    file_put_contents($caminho_arquivo, $conteudo);
}

// Limpa todo o cache do sistema
function limpar_todo_cache(){
    $pasta_cache = __DIR__ . '/../data/cache/';
    if(is_dir($pasta_cache)){
        $arquivos = glob($pasta_cache . '*.cache');
        foreach($arquivos as $arquivo){
            unlink($arquivo);
        }
    }
}
?>

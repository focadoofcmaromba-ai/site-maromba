<?php
function gerar_seo_completo($dados_seo){
    global $configuracao_site;

    $dados_padrao = [
        'tipo' => 'website',
        'titulo' => $configuracao_site['nome_site'],
        'descricao' => $configuracao_site['descricao_geral'],
        'url' => $configuracao_site['url_base'] . $_SERVER['REQUEST_URI'],
        'imagem' => $configuracao_site['url_base'].'/assets/imagem-compartilhamento.jpg',
        'autor' => '',
        'data_publicacao' => '',
        'data_modificacao' => ''
    ];
    $dados = array_merge($dados_padrao, $dados_seo);

    $saida = '';
    // JSON-LD Article
    if($dados['tipo'] == 'article'){
        $json_ld = [
            "@context" => "https://schema.org",
            "@type" => "Article",
            "headline" => $dados['titulo'],
            "description" => $dados['descricao'],
            "author" => ["@type" => "Person", "name" => $dados['autor']],
            "datePublished" => $dados['data_publicacao'],
            "dateModified" => $dados['data_modificacao'],
            "image" => $dados['imagem']
        ];
        $saida .= '<script type="application/ld+json">'.json_encode($json_ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES).'</script>';
    }

    return $saida;
}
?>
